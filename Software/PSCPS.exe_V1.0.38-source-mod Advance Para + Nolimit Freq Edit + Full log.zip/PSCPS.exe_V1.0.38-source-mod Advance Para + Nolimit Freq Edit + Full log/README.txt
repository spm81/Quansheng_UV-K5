Portable Radio Update Tools V1.1.12 mod

removed edit frequency limitation 
enabled Advance Para secret menu 
added packet logging 
source code included

To build download Visual Studio 2010 Ultimate
https://archive.org/details/en_vs_2010_ult

Install in this order:
1. Visual Studio 2010
2. Windows SDK 7.1
3. Windows WDK 7.1
4. Visual Studio 2010 SP1
5. Visual Studio Updates

Open Projects *.csproj and build :)
